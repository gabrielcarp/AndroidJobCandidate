package app.storytel.candidate.com.intermediary.entitites;

public class Comment {
    public int postId;
    public int id;
    public String name;
    public String email;
    public String body;
}
