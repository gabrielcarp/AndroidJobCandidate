package app.storytel.candidate.com.ui;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

import app.storytel.candidate.com.R;
import app.storytel.candidate.com.intermediary.PostAndImages;
import app.storytel.candidate.com.intermediary.entitites.Photo;
import app.storytel.candidate.com.intermediary.entitites.Post;

public class DetailsActivity extends AppCompatActivity {
    private static final String COMMENTS_URL = "https://jsonplaceholder.typicode.com/posts/{id}/comments";
    private ImageView mImageView;
    private TextView mTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        mImageView = findViewById(R.id.backdrop);
        mTextView = findViewById(R.id.details);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        new AsyncTask<Void, Void, PostAndImages>() {
            @Override
            protected PostAndImages doInBackground(Void... voids) {
                List<Post> posts = getPosts();
                List<Photo> photos = getPhotos();
                return new PostAndImages(posts, photos);
            }

            private List<Post> getPosts()
            {
                List<Post> posts = null;
                InputStream stream = null;
                HttpURLConnection urlConnection = null;
                try {
                    String result = null;
                    URL url = new URL(POSTS_URL);
                    urlConnection = (HttpURLConnection) url.openConnection();
                    urlConnection.connect();
                    int responseCode = urlConnection.getResponseCode();
                    if (responseCode != HttpsURLConnection.HTTP_OK) {
                        throw new IOException("HTTP error code: " + responseCode);
                    }
                    stream = urlConnection.getInputStream();
                    if (stream != null) {
                        result = readStream(stream);
                        Post[] array = new Gson().fromJson(result, Post[].class);
                        posts = Arrays.asList(array);
                    }
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    if (stream != null) {
                        try {
                            stream.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    if (urlConnection != null) {
                        urlConnection.disconnect();
                    }
                }

                return posts;
            }

            private List<Photo> getPhotos()
            {
                List<Photo> photos = null;
                InputStream stream = null;
                HttpURLConnection urlConnection = null;
                try {
                    String result = null;
                    URL url = new URL(PHOTOS_URL);
                    urlConnection = (HttpURLConnection) url.openConnection();
                    urlConnection.connect();
                    int responseCode = urlConnection.getResponseCode();
                    if (responseCode != HttpsURLConnection.HTTP_OK) {
                        throw new IOException("HTTP error code: " + responseCode);
                    }
                    stream = urlConnection.getInputStream();
                    if (stream != null) {
                        result = readStream(stream);
                        Photo[] array = new Gson().fromJson(result, Photo[].class);
                        photos = Arrays.asList(array);
                    }
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    if (stream != null) {
                        try {
                            stream.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    if (urlConnection != null) {
                        urlConnection.disconnect();
                    }
                }

                return photos;
            }

            /**
             * Converts the contents of an InputStream to a String.
             */
            public String readStream(InputStream stream)
                    throws IOException, UnsupportedEncodingException {
                Reader reader = null;
                reader = new InputStreamReader(stream, "UTF-8");
                char[] rawBuffer = new char[256];
                int readSize;
                StringBuffer buffer = new StringBuffer();
                while (((readSize = reader.read(rawBuffer)) != -1)) {
                    buffer.append(rawBuffer, 0, readSize);
                }
                return buffer.toString();
            }

            @Override
            protected void onPostExecute(PostAndImages result) {
                mPostAdapter.setData(result);
            }

        }.execute();
        //TODO display the selected post from ScrollingActivity. Use mImageView and mTextView for image and body text. Change the title to use the post title
        //TODO load top 3 comments from COMMENTS_URL into the 3 card views
    }

}
