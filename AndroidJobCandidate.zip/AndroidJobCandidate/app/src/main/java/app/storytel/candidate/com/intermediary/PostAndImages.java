package app.storytel.candidate.com.intermediary;

import java.util.List;

import app.storytel.candidate.com.intermediary.entitites.Photo;
import app.storytel.candidate.com.intermediary.entitites.Post;

public class PostAndImages {
    public List<Post> mPosts;
    public List<Photo> mPhotos;

    public PostAndImages(List<Post> post, List<Photo> photos) {
        mPosts = post;
        mPhotos = photos;
    }
}
