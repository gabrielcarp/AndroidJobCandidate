package app.storytel.candidate.com.intermediary.entitites;

public class Post {
    public int userId;
    public int id;
    public String title;
    public String body;
}
